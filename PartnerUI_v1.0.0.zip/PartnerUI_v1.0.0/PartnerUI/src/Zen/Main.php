<?php

namespace Zen;

use pocketmine\plugin\PluginBase;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\event\Listener;
use jojoe77777\FormAPI;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\utils\Config;
use pocketmine\event\player\PlayerCommandPreprocessEvent;
use pocketmine\event\server\ServerCommandEvent;
use pocketmine\Player;
use pocketmine\Server;
use Zen\Main;

class Main extends PluginBase implements Listener{
    
    public function onEnable(){
        $this->getLogger()->info("§aPartnerUI has been activated.");
        $this->getServer()->getPluginManager()->registerEvents($this, $this);
    }

    public function checkDepends(){
        $this->formapi = $this->getServer()->getPluginManager()->getPlugin("FormAPI");
        if(is_null($this->formapi)){
            $this->getLogger()->error("§4Please install FormAPI Plugin, disabling PartnerUI...");
            $this->getPluginLoader()->disablePlugin($this);
        }
    }

    public function onCommand(CommandSender $sender, Command $cmd, string $label, array $args):bool{
        if($cmd->getName() == "partner"){
        if(!($sender instanceof Player)){
                $sender->sendMessage("§cPlease use this command from In-game!", false);
                return true;
                $player = $sender
        }
        $api = $this->getServer()->getPluginManager()->getPlugin("FormAPI");
        $form = $api->createSimpleForm(function (Player $sender, $data){
            $result = $data;
            if ($result == null) {
            }
            switch ($result) {
                    case 0:
                    $this->getServer()->getCommandMap()->dispatch($player, "transferserver pixelbe.ddns.net 25636")
                        break;
                    case 1:
                    $this->getServer()->getCommandMap()->dispatch($player, "tell {player} SOON!");
                        break;
                    case 2:
                        break;
            }
        });
        $form->setContent("Partners");
        $form->addButton("§cPixelBE", 0);
        $form->addButton("SOON!", 1);
        $form->addButton("Exit", 2);
        $form->sendToPlayer($sender);
        }
        return true;
    }
    
    public function handleJoin(PlayerJoinEvent $ev) {
        $player = $ev->getPlayer();
        $inventory = $player->getInventory();
        $player->getInventory()->clearAll();
        $inventory->setItem(1, Item::get(Item::CLOCK, 0)->setCustomName("§r§dPartners"));
    }

    public function handleInteraction(PlayerInteractEvent $ev) {
        $level = $ev->getPlayer()->getLevel();
        $player = $ev->getPlayer();
        $inventory = $player->getInventory();
        $hand = $inventory->getItemInHand();
        switch ($hand->getId()) {
            case Item::CLOCK:
            $command = "partner";
            $this->plugin->getServer()->getCommandMap()->dispatch($player, $command);
            break;
        }
     }

    public function onDisable(){
        $this->getLogger()->info("§cDisabling PartnerUI by Zen...");
    }
}
